import pandas as pd

movies = pd.read_csv('mvdataset.csv')

print(movies)