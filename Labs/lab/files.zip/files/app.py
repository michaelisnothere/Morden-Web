import streamlit as st
import pickle
import requests


movies = pickle.load(open('movies_list.pkl', 'rb'))
similarity = pickle.load(open('similarity.pkl', 'rb'))

movies_list = movies['title'].values

st.header("Movie Recommender")
selected = st.selectbox('Select Movie', movies_list)

def fetch_poster(movie_id):
    url = f'https://api.themoviedb.org/3/movie/{movie_id}?api_key=d947b99199fd702c2b87057471b12fdc&language=en-US'
    data = requests.get(url).json()
    if 'poster_path' not in data:
        print(f"Error: 'poster_path' not found for movie_id {movie_id}. Response: {data}")
        return None
    poster_path = data['poster_path']
    full_path = 'https://image.tmdb.org/t/p/w500' + poster_path
    return full_path

def recommand(movie):
    index = movies[movies['title'] == movie].index[0]
    distance = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda vector: vector[1])
    recommand_movie = []
    recommand_poster = []
    for i in distance[1:11]:
        movies_id = movies.iloc[i[0]].id
        poster = fetch_poster(movies_id)
        if poster:
            recommand_movie.append(movies.iloc[i[0]].title)
            recommand_poster.append(poster)
        else:
            recommand_movie.append(movies.iloc[i[0]].title)
            recommand_poster.append("https://via.placeholder.com/500x750?text=No+Image")
    return recommand_movie, recommand_poster

if st.button('Recommend'):
    movie_names, movie_poster = recommand(selected)
    col1, col2, col3, col4, col5, col6, col7, col8, col9, col10 = st.columns(10)
    with col1:
        st.text(movie_names[0])
        st.image(movie_poster[0])
    with col2:
        st.text(movie_names[1])
        st.image(movie_poster[1])
    with col3:
        st.text(movie_names[2])
        st.image(movie_poster[2])
    with col4:
        st.text(movie_names[3])
        st.image(movie_poster[3])
    with col5:
        st.text(movie_names[4])
        st.image(movie_poster[4])
    with col6:
        st.text(movie_names[5])
        st.image(movie_poster[5])
    with col7:
        st.text(movie_names[6])
        st.image(movie_poster[6])
    with col8:
        st.text(movie_names[7])
        st.image(movie_poster[7])
    with col9:
        st.text(movie_names[8])
        st.image(movie_poster[8])
    with col10:
        st.text(movie_names[9])
        st.image(movie_poster[9])

